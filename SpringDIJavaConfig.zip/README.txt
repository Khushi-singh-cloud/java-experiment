Spring Dependency Injection Example (Java-Based Configuration)

How to Run:
1. Ensure you have Spring Core libraries in your classpath.
2. Compile all Java files:
   javac -cp spring-context-<version>.jar com/example/springdi/*.java
3. Run the MainApp class:
   java -cp .:spring-context-<version>.jar com.example.springdi.MainApp

Expected Output:
Student enrolled in course: Spring Framework Fundamentals
