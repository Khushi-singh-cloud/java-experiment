# Online Student Management System using Spring + Hibernate

## Requirements
- Java 11+
- MySQL Database
- Spring Framework
- Hibernate ORM
- Maven/Gradle (for dependencies)

## Steps to Run
1. Create database:
   ```sql
   CREATE DATABASE studentdb;
   ```
2. Update MySQL username/password in `AppConfig.java`.
3. Compile and run:
   ```bash
   javac -cp "path_to_spring_jar;path_to_hibernate_jar;." com/project/main/MainApp.java
   java com.project.main.MainApp
   ```
4. Use the console menu to manage students, view data, and test transactions.
