import java.util.List;

public class MainApp {
    public static void main(String[] args) {
        StudentDAO dao = new StudentDAO();

        // Create
        dao.saveStudent(new Student("Alice", "alice@example.com"));
        dao.saveStudent(new Student("Bob", "bob@example.com"));

        // Read
        List<Student> students = dao.getAllStudents();
        students.forEach(System.out::println);

        // Update
        Student student = dao.getStudent(1);
        if (student != null) {
            student.setEmail("alice_updated@example.com");
            dao.updateStudent(student);
        }

        // Delete
        dao.deleteStudent(2);

        HibernateUtil.getSessionFactory().close();
    }
}
