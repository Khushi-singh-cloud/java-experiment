package com.project.main;

import com.project.config.AppConfig;
import com.project.dao.StudentDAO;
import com.project.model.Course;
import com.project.model.Student;
import com.project.service.FeeService;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        StudentDAO dao = context.getBean(StudentDAO.class);
        FeeService feeService = context.getBean(FeeService.class);

        Scanner sc = new Scanner(System.in);
        System.out.println("=== Online Student Management System ===");
        while (true) {
            System.out.println("\n1. Add Student\n2. View All\n3. Pay Fee\n4. Refund Fee\n5. Exit");
            int choice = sc.nextInt();
            sc.nextLine();
            if (choice == 1) {
                System.out.print("Enter name: ");
                String name = sc.nextLine();
                System.out.print("Enter balance: ");
                double balance = sc.nextDouble();
                Course c = new Course("Java", 3);
                Student s = new Student(name, balance, c);
                dao.addStudent(s);
                System.out.println("Student added.");
            } else if (choice == 2) {
                dao.getAllStudents().forEach(s -> 
                    System.out.println(s.getStudentId() + " " + s.getName() + " " + s.getBalance()));
            } else if (choice == 3) {
                System.out.print("Enter student ID: ");
                int id = sc.nextInt();
                System.out.print("Enter amount: ");
                double amt = sc.nextDouble();
                Student s = dao.getAllStudents().stream().filter(x -> x.getStudentId() == id).findFirst().orElse(null);
                if (s != null) feeService.payFee(s, amt);
            } else if (choice == 4) {
                System.out.print("Enter student ID: ");
                int id = sc.nextInt();
                System.out.print("Enter amount: ");
                double amt = sc.nextDouble();
                Student s = dao.getAllStudents().stream().filter(x -> x.getStudentId() == id).findFirst().orElse(null);
                if (s != null) feeService.refundFee(s, amt);
            } else break;
        }
        context.close();
    }
}
