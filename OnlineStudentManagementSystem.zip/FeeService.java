package com.project.service;

import com.project.model.Student;
import com.project.dao.StudentDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class FeeService {
    @Autowired
    private StudentDAO studentDAO;

    @Transactional
    public void payFee(Student student, double amount) {
        if (student.getBalance() >= amount) {
            student.setBalance(student.getBalance() - amount);
            studentDAO.updateStudent(student);
            System.out.println("Payment successful for: " + student.getName());
        } else {
            throw new RuntimeException("Insufficient balance.");
        }
    }

    @Transactional
    public void refundFee(Student student, double amount) {
        student.setBalance(student.getBalance() + amount);
        studentDAO.updateStudent(student);
        System.out.println("Refund successful for: " + student.getName());
    }
}
