Student Attendance Portal (JSP + Servlet + JDBC)
----------------------------------------------------
1. Place 'attendance.jsp' inside the webapp folder (WebContent).
2. Place 'AttendanceServlet.java' under src/com/example/.
3. Update database URL, username, and password in the servlet file.
4. Create a MySQL database 'schooldb' with table:

   CREATE TABLE Attendance (
       StudentID VARCHAR(20),
       Date DATE,
       Status VARCHAR(10)
   );

5. Deploy the project in Apache Tomcat (Nimbus or local).
6. Run via http://localhost:8080/AttendancePortal/attendance.jsp
