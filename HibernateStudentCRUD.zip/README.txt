Hibernate CRUD Application - Student Management

Steps to run:
1. Create MySQL database: CREATE DATABASE testdb;
2. Update username/password in hibernate.cfg.xml if needed.
3. Compile all .java files:
   javac -cp "path/to/hibernate/jars/*" *.java
4. Run:
   java -cp ".;path/to/hibernate/jars/*" MainApp

This application performs:
- Create, Read, Update, Delete operations on Student entity using Hibernate ORM.
